
const MapComponents = () => {
    <div>
        <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ea dignissimos perferendis sequi minus vero voluptate quas culpa quos sint aspernatur.
</p>
    </div>
}

export default MapComponents;
