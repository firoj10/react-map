import LeafletMap from "./components/LeafletMap";
function App() {
  return (
    <div>
    <LeafletMap />

   </div>
  );
}

export default App;
